# CHANGE THESE BEFORE PUBLIC DEPLOYMENT.
SECRET_KEY = "replace-this-with-a-long-random-secret-key"

# Intentionally NOT /admin.
ADMIN_PATH = "control-room-k7p4x9"

ADMIN_USERNAME = "ggl_owner"
ADMIN_PASSWORD = "ChangeThis-GGL-Admin-2026!"

DATABASE = "ggl_qr.sqlite3"

# Used to create privacy-safe IP fingerprints. Raw IPs are not stored.
IP_HASH_SECRET = "replace-this-with-a-second-long-random-secret"
